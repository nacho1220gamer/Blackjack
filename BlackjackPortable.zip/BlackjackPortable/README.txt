# Blackjack Game - Versión Portable 
================================== 
 
Juego de Blackjack desarrollado en C++ con wxWidgets 
Compilado desde Visual Studio 
 
## COMO EJECUTAR: 
================== 
1. Doble clic en "Ejecutar_Blackjack.bat" (recomendado) 
2. O directamente en "Blackjack.exe" 
 
## REQUISITOS DEL SISTEMA: 
========================== 
- Windows 10 o superior 
- Arquitectura x64 o x86 
- Visual C++ Redistributable (si no funciona) 
 
## SOLUCION DE PROBLEMAS: 
========================= 
Si el juego no inicia, descarga e instala: 
Visual C++ Redistributable 2019-2022 
Link: https://aka.ms/vs/17/release/vc_redist.x64.exe 
 
Creado por: [Tu nombre] 
Fecha: jue. 19/06/2025 
